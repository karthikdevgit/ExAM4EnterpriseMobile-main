import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-file-am-question',
  templateUrl: './file-am-question.component.html',
  styleUrls: ['./file-am-question.component.scss'],
})
export class FileAmQuestionComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
