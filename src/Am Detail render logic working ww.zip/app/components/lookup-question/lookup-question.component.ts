import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lookup-question',
  templateUrl: './lookup-question.component.html',
  styleUrls: ['./lookup-question.component.scss'],
})
export class LookupQuestionComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
