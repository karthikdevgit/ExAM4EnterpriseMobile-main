import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-each-amdetail-render',
  templateUrl: './each-amdetail-render.component.html',
  styleUrls: ['./each-amdetail-render.component.scss'],
})
export class EachAMDetailRenderComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
