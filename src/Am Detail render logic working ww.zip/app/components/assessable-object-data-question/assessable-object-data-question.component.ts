import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-assessable-object-data-question',
  templateUrl: './assessable-object-data-question.component.html',
  styleUrls: ['./assessable-object-data-question.component.scss'],
})
export class AssessableObjectDataQuestionComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
