import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-related-records',
  templateUrl: './related-records.page.html',
  styleUrls: ['./related-records.page.scss'],
})
export class RelatedRecordsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
