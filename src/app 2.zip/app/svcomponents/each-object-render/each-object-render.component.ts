import { Component,Input, OnInit } from '@angular/core';
import { resolve } from 'dns';

@Component({
  selector: 'app-each-object-render',
  templateUrl: './each-object-render.component.html',
  styleUrls: ['./each-object-render.component.scss'],
})
export class EachObjectRenderComponent implements OnInit {
  @Input() eachassessableObject: any;
  @Input() schemaViewData: any;
  @Input() currentIndex: any;
  @Input() isfromTreeView:boolean;
  isHaveChild=false;
  componentRenderSuccess=false;
  constructor() { }

  ngOnInit() {
    var _this=this;
    console.log('EachObjectRenderComponent ngOnInit textthis.assessableObject',_this.eachassessableObject);

    console.log('EachObjectRenderComponent this.schemaViewData',_this.schemaViewData);
    console.log('EachObjectRenderComponent this.currentIndex',_this.currentIndex);
  }
  RelatedChildRendercall() {
    console.log('RelatedChildRendercall');
    var _this=this;
    if (this.isHaveChild) {
      this.isHaveChild = false;
    } else {
      this.isHaveChild = true;
    }
  }
 
  ishaveChild(schemaViewData,currentIndex,eachassessableObject){
       // return new Promise((resolve, reject) => {
        
     var ishaveChild=false;
          if(schemaViewData &&
            schemaViewData[currentIndex] &&
            schemaViewData[currentIndex].relatedObjectsIndex &&
            schemaViewData[currentIndex].relatedObjectsIndex.length > 0){
              Object.keys(schemaViewData[currentIndex]
                .relatedObjectsIndex).forEach(function(relatedObjectsIndex){
                  console.log('relatedObjectsIndex',relatedObjectsIndex);
                  var relatedIndex=schemaViewData[currentIndex]
                  .relatedObjectsIndex[relatedObjectsIndex];
                  console.log('relatedIndex',relatedIndex);

                  if( schemaViewData &&
                    schemaViewData[relatedIndex] &&
                    schemaViewData[relatedIndex].childAssessableObjs &&
                    schemaViewData[relatedIndex].childAssessableObjs[
                      eachassessableObject.Id
                    ] &&
                    schemaViewData[relatedIndex].childAssessableObjs[
                      eachassessableObject.Id
                    ].length > 0){
                      console.log('ishaveChild',ishaveChild);
                      ishaveChild=true;
                      return ishaveChild;
                    }
                })
                console.log('outside loop ishaveChild',ishaveChild);

                return ishaveChild;
            }else{
              return ishaveChild;
            }
      //});
     }
}
