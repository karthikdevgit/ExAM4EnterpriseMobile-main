import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hot-spot-image-question',
  templateUrl: './hot-spot-image-question.component.html',
  styleUrls: ['./hot-spot-image-question.component.scss'],
})
export class HotSpotImageQuestionComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
