import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-timer-question',
  templateUrl: './timer-question.component.html',
  styleUrls: ['./timer-question.component.scss'],
})
export class TimerQuestionComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
