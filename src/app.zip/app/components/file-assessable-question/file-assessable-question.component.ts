import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-file-assessable-question',
  templateUrl: './file-assessable-question.component.html',
  styleUrls: ['./file-assessable-question.component.scss'],
})
export class FileAssessableQuestionComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
