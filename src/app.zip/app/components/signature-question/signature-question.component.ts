import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-signature-question',
  templateUrl: './signature-question.component.html',
  styleUrls: ['./signature-question.component.scss'],
})
export class SignatureQuestionComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
