import { Component, Input, OnInit } from "@angular/core";
import { Injectable, NgZone } from '@angular/core';
import { ActivatedRoute,Router, NavigationExtras } from '@angular/router';
import { GlobalParamService } from "src/app/service/global-param.service";
@Component({
  selector: "app-tree-view-not-enabled",
  templateUrl: "./tree-view-not-enabled.component.html",
  styleUrls: ["./tree-view-not-enabled.component.scss"],
})
export class TreeViewNotEnabledComponent implements OnInit {
  @Input() schemaViewData: any;
  @Input() currentIndex: any;
  
  @Input() parentId: any;
  index: number;

  constructor(private zone: NgZone,private router: Router,public activatedRoute : ActivatedRoute,public GlobalParamService:GlobalParamService) {
    var _this = this;
    console.log(
      "Date tree-view-not-enabled  comp[onent].schemaViewData",
      _this.schemaViewData
    );
    _this.router.routeReuseStrategy.shouldReuseRoute = function () {
      return false;
    };
    _this.router.onSameUrlNavigation = 'reload';
    console.log("currentIndex", _this.currentIndex);
  }

  ngOnInit() {
    var _this = this;
    console.log(
      "Date tree-view-not-enabled ngOnInit comp[onent].schemaViewData",
      _this.schemaViewData
    );
    console.log("currentIndex", _this.currentIndex);
    
  }
  toNumber(value: string): number {
    return parseInt(value);
  }
  
  // async relatedObject(schemaViewData: any, relatedIndex: any,parentId: any) {
  //   var _this=this;
  //   console.log('schemaViewData',schemaViewData);
  //   console.log('relatedIndex',relatedIndex);
  //   console.log('parentId',parentId);
  //   _this.index++;

  //   let navigationExtras = {
  //     state: {
  //       schemaViewData:schemaViewData,
  //       relatedIndex:relatedIndex,
  //       parentId:parentId,
  //     }
     
  //   };
  //   console.log('navigationExtras',navigationExtras);
   
  //   _this.zone.run(() => {
  //     // _this.router.navigate(['/related-object'], {
  //     //   relativeTo: _this.activatedRoute,
  //     //   queryParams: { index: _this.index, schemaViewData:JSON.stringify(schemaViewData),
  //     //     relatedIndex:relatedIndex,
  //     //     parentId:parentId, },
  //     //   queryParamsHandling: 'merge'
  //     // });
  //     _this.router.navigate(['/related-object'],navigationExtras);
  //   });

  // }

}
