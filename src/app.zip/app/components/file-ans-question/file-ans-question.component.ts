import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-file-ans-question',
  templateUrl: './file-ans-question.component.html',
  styleUrls: ['./file-ans-question.component.scss'],
})
export class FileAnsQuestionComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
