import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ForceApiService } from 'src/app/service/force-api.service';
import { LaunchServiceService } from 'src/app/service/launch-service.service';
import { Platform, AlertController,MenuController, ModalController,PopoverController } from '@ionic/angular';
//import { StatusBar } from '@ionic-native/status-bar/ngx';
import { Network } from '@ionic-native/network/ngx';
declare var window: any;
@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent {
 
  public hasNetwork: any;
  public UserName = '';

  constructor(
    private network: Network,
   // private statusBar: StatusBar,
    private platform: Platform, 
    private router: Router, 
    private forceapi: ForceApiService, 
    private launchService: LaunchServiceService) {
    var _this = this;
 
   this.initializeApp();
    
    console.log('called');
  }

  initializeApp() {
    this.platform.ready().then(() => {
      var _this = this;
     // this.statusBar.styleDefault();
      this.hasNetwork = this.network.type != 'none' ? true: false;
      this.launchService.launchservice();
      
    });
  }

}
